%% Initializing the enviroment
    close all
    clear
    clc
    
   
%% Load the functions 
    PATH_Current = cd;
    PATH_Functions = genpath(strrep(PATH_Current, 'Experiments-1', 'MyFunctions'));
    addpath(PATH_Functions);

   
%% Load the image data
  % Load the image
    Image_Original = double(imread('Lena.jpg'));
    Size_Image = size(Image_Original, 1);

    
%% Public settings
    Size_Window = 16;
    Length_Segment = Size_Window^2;
    NUM_Row_OR_Column = Size_Image/Size_Window;
    Row_IndexGuider = kron(ones(1, NUM_Row_OR_Column), (1:NUM_Row_OR_Column)');
    Column_IndexGuider = Row_IndexGuider';
    mRate_Set = 0.1:0.05:0.7;
    NUM_mRate_Set = length(mRate_Set);
    
    
%% Settings for BPDN
    lambda = 1e-5;
    Options.gamma = 1e3;
    Options.MAX_ITER = 500;
    
   
%% Main
    PSNR_mRate = zeros(NUM_mRate_Set, 1);
    SSIM_mRate = zeros(NUM_mRate_Set, 1);
    for i = 1:NUM_mRate_Set
        rng('default')
        m = round(mRate_Set(i)*Length_Segment);
        A_randn = randn(m, Length_Segment);
        A = DesignGrass(m, Length_Segment, 2e3, 0.90, 0.90, A_randn);
        
        Image_Recovered = zeros(Size_Image, Size_Image);
        for k = 1:(NUM_Row_OR_Column^2)

          % The index of the i-th segment
            Row_Index = (Size_Window*(Row_IndexGuider(k)-1) + 1):(Size_Window*Row_IndexGuider(k));
            Column_Index = (Size_Window*(Column_IndexGuider(k)-1) + 1):(Size_Window*Column_IndexGuider(k));
          % Obtain the i-th segment
            Segment_Original = Image_Original(Row_Index, Column_Index);
            
          % Prepare for the input data
            FRONorm_Segment = norm(Segment_Original,  'fro');
            Segment_Normalization = Segment_Original/FRONorm_Segment;
            C = dct2(Segment_Normalization);
            x_Original = C(:);
            
          % Sampling
            b = A*x_Original;
            
          % Solve by BPDN
            Options.x_Original = x_Original;
            x_sharp = BPDN(A, b, lambda, Options);
            
          % Output the imgae
            C_Recovered = reshape(x_sharp, Size_Window, Size_Window);
            Segment_Recovered = idct2(C_Recovered);
            Image_Recovered(Row_Index, Column_Index) = FRONorm_Segment*Segment_Recovered;
            
        end
        
        Image_Recovered = max(Image_Recovered, 0);
        Image_Recovered = min(Image_Recovered, 255);
        PSNR_mRate(i) = PSNR(Image_Original, Image_Recovered, ones(Size_Image, Size_Image));
        SSIM_mRate(i) = ssim_index(Image_Original, Image_Recovered); 
        
    end

   
%% Figure
    figure
    yyaxis left
    h1 = plot(mRate_Set, PSNR_mRate, 'LineWidth', 2);        
    ylabel('PSNR(dB)', 'FontSize', 20)
    yyaxis right
    h2 = plot(mRate_Set, SSIM_mRate, 'LineWidth', 2);
    xlabel('Sampling rate (m/n)', 'FontSize', 20)
    ylabel('SSIM', 'FontSize', 20)
    grid on 
    
    
%% Save data
    save FIGURE7
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions);
   