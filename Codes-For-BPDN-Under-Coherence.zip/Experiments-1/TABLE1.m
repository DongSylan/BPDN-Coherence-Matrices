%% Initializing the enviroment
    close all
    clear 
    clc
    rng('default')
    
    
%% Load the functions 
    PATH_Current = cd;
    PATH_Functions = genpath(strrep(PATH_Current, 'Experiments-1', 'MyFunctions'));
    addpath(PATH_Functions);

   
%% Load the image data and coherence matrix
    Name_ImagesFile   = 'Images-Gray';
  % Load the Images
    Dir_Images        = dir(fullfile(Name_ImagesFile, '*.jpg'));
    Name_Images       = {Dir_Images.name};
    Num_Images        = length(Name_Images);
  % Load the coherence matrix
    load Coherence_Matrix_04Rate.mat
    
    
%% Public settings
    Size_Image = 256;
    Size_Window = 16;
    Length_Segment = Size_Window^2;
    NUM_Row_OR_Column = Size_Image/Size_Window;
    Row_IndexGuider = kron(ones(1, NUM_Row_OR_Column), (1:NUM_Row_OR_Column)');
    Column_IndexGuider = Row_IndexGuider';
    Index_Full = ones(Size_Image, Size_Image);
    
    
%% Parameter setings for algorithms
  % IHT
    sRate_IHT = 0.06;
    s_IHT = round(sRate_IHT*Length_Segment);
  % ROMP
    sRate_ROMP = 0.03;
    s_ROMP = round(sRate_ROMP*Length_Segment);
  % SP
    sRate_SP = 0.07;
    s_SP = round(sRate_SP*Length_Segment);
  % BPDN
    lambda_BPDN = 1e-5;
    opts_BPDN.gamma = 1e3;
    opts_BPDN.MAX_ITER = 500;
    
    
%% File address
    File_Address = 'Image_Recovered\';
    mkdir('Image_Recovered') 
    
   
%% Main
    PSNR_Algorithms = zeros(4, Num_Images);
    SSIM_Algorithms = zeros(4, Num_Images);
    for i = 1:Num_Images

      % Load the i-th image
        NameImage_Long  = strcat([Name_ImagesFile '\'], Name_Images{i});
        Image_Original = double(imread(NameImage_Long));
        Size_Image = size(Image_Original, 1);
        
        Image_Recovered_IHT = zeros(Size_Image, Size_Image);
        Image_Recovered_ROMP = zeros(Size_Image, Size_Image);
        Image_Recovered_SP = zeros(Size_Image, Size_Image);
        Image_Recovered_BPDN = zeros(Size_Image, Size_Image);
        for k = 1:(NUM_Row_OR_Column^2)
            
          % The index of the i-th segment
            Row_Index = (Size_Window*(Row_IndexGuider(k)-1) + 1):(Size_Window*Row_IndexGuider(k));
            Column_Index = (Size_Window*(Column_IndexGuider(k)-1) + 1):(Size_Window*Column_IndexGuider(k));
          % Obtain the i-th segment
            Segment_Original = double(Image_Original(Row_Index, Column_Index));
            
          % Prepare for the input data
            FRONorm_Segment = norm(Segment_Original,  'fro');
            Segment_Normalization = Segment_Original/FRONorm_Segment;
            C = dct2(Segment_Normalization);
            x_Original = C(:);
            
          % Sampling
            b = A*x_Original;
            
          % ------ Solve by IHT
            x_sharp_IHT = hard_l0_Mterm(b, A, Length_Segment, s_IHT);
            C_Recovered_IHT = reshape(x_sharp_IHT, Size_Window, Size_Window);
            Segment_Recovered_IHT = idct2(C_Recovered_IHT);
            Image_Recovered_IHT(Row_Index, Column_Index) = FRONorm_Segment*Segment_Recovered_IHT;
            
          % ------ Solve by ROMP
            x_sharp_ROMP = romp(A, b, s_ROMP);
            C_Recovered_ROMP = reshape(x_sharp_ROMP, Size_Window, Size_Window);
            Segment_Recovered_ROMP = idct2(C_Recovered_ROMP);
            Image_Recovered_ROMP(Row_Index, Column_Index) = FRONorm_Segment*Segment_Recovered_ROMP;
            
          % ------ Solve by SP
            x_sharp_SP = CSRec_SP(s_SP, A, b); 
            C_Recovered_SP = reshape(x_sharp_SP, Size_Window, Size_Window);
            Segment_Recovered_SP = idct2(C_Recovered_SP);
            Image_Recovered_SP(Row_Index, Column_Index) = FRONorm_Segment*Segment_Recovered_SP;
            
          % ------ Solve by BPDN
            opts_BPDN.x_Original = x_Original;
            x_sharp_BPDN = BPDN(A, b, lambda_BPDN, opts_BPDN);
            C_Recovered_BPDN = reshape(x_sharp_BPDN, Size_Window, Size_Window);
            Segment_Recovered_BPDN = idct2(C_Recovered_BPDN);
            Image_Recovered_BPDN(Row_Index, Column_Index) = FRONorm_Segment*Segment_Recovered_BPDN;
            
        end
        
      % Statistical results for IHT
        Image_Recovered_IHT = max(Image_Recovered_IHT, 0);
        Image_Recovered_IHT = min(Image_Recovered_IHT, 255);
        PSNR_IHT = PSNR(Image_Original, Image_Recovered_IHT, Index_Full);
        PSNR_Algorithms(1, i) = PSNR_IHT;
        SSIM_IHT = ssim_index(Image_Original, Image_Recovered_IHT);
        SSIM_Algorithms(1, i) = SSIM_IHT;
        figure
        imshow(uint8(Image_Recovered_IHT))
        % ----- Maximun window of current fig-type picture ----- %
        set(gcf, 'outerposition', get(0, 'screensize'));
% ----- Maximun window of current fig-type picture ----- %
        saveas(gcf, [File_Address strrep(Name_Images{i}, '.jpg', '-IHT.jpg')])
        saveas(gcf, [File_Address strrep(Name_Images{i}, '.jpg', '-IHT.fig')])
        
      % Statistical results for ROMP
        Image_Recovered_ROMP = max(Image_Recovered_ROMP, 0);
        Image_Recovered_ROMP = min(Image_Recovered_ROMP, 255);
        PSNR_ROMP = PSNR(Image_Original, Image_Recovered_ROMP, Index_Full);
        PSNR_Algorithms(2, i) = PSNR_ROMP;
        SSIM_ROMP = ssim_index(Image_Original, Image_Recovered_ROMP);
        SSIM_Algorithms(2, i) = SSIM_ROMP;
        figure
        imshow(uint8(Image_Recovered_ROMP))
        % ----- Maximun window of current fig-type picture ----- %
        set(gcf, 'outerposition', get(0, 'screensize'));
% ----- Maximun window of current fig-type picture ----- %
        saveas(gcf, [File_Address strrep(Name_Images{i}, '.jpg', '-ROMP.jpg')])
        saveas(gcf, [File_Address strrep(Name_Images{i}, '.jpg', '-ROMP.fig')])
        
      % Statistical results for SP
        Image_Recovered_SP = max(Image_Recovered_SP, 0);
        Image_Recovered_SP = min(Image_Recovered_SP, 255);
        PSNR_SP = PSNR(Image_Original, Image_Recovered_SP, Index_Full);
        PSNR_Algorithms(3, i) = PSNR_SP;
        SSIM_SP = ssim_index(Image_Original, Image_Recovered_SP);
        SSIM_Algorithms(3, i) = SSIM_SP;
        figure
        imshow(uint8(Image_Recovered_SP))
        % ----- Maximun window of current fig-type picture ----- %
        set(gcf, 'outerposition', get(0, 'screensize'));
% ----- Maximun window of current fig-type picture ----- %
        saveas(gcf, [File_Address strrep(Name_Images{i}, '.jpg', '-SP.jpg')])
        saveas(gcf, [File_Address strrep(Name_Images{i}, '.jpg', '-SP.fig')])
        
      % Statistical results for BPDN
        Image_Recovered_BPDN = max(Image_Recovered_BPDN, 0);
        Image_Recovered_BPDN = min(Image_Recovered_BPDN, 255);
        PSNR_BPDN = PSNR(Image_Original, Image_Recovered_BPDN, Index_Full);
        PSNR_Algorithms(4, i) = PSNR_BPDN;
        SSIM_BPDN = ssim_index(Image_Original, Image_Recovered_BPDN);
        SSIM_Algorithms(4, i) = SSIM_BPDN;
        figure
        imshow(uint8(Image_Recovered_BPDN))
        % ----- Maximun window of current fig-type picture ----- %
        set(gcf, 'outerposition', get(0, 'screensize'));
% ----- Maximun window of current fig-type picture ----- %
        saveas(gcf, [File_Address strrep(Name_Images{i}, '.jpg', '-BPDN.jpg')])
        saveas(gcf, [File_Address strrep(Name_Images{i}, '.jpg', '-BPDN.fig')])
        
        close all
        
    end
    
    
%% Save data
    save TABLE1
    
    
%% Show
    disp(vpa(PSNR_Algorithms, 4))
    disp(vpa(SSIM_Algorithms, 3))
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions);
   