%% Initialize the enviroment
    close all
    clear 
    clc
    rng('default')


%% Load the data and toolbox
    Gray_Imgaes = uint8(zeros(256*4, 256*5));
    k = 1;
    for i = 1:4
        iIndex = (256*(i-1) + 1):(256*i);
        for j = 1:5
            jIndex = (256*(j-1) + 1):(256*j);
            % Load the data
            if k < 10
                Name_Pic = ['Images-Gray\0' num2str(k)  '.jpg'];
            else
                Name_Pic = ['Images-Gray\' num2str(k)  '.jpg'];
            end
            Image_Gray_ij = imread(Name_Pic);
            Gray_Imgaes(iIndex, jIndex, :) = Image_Gray_ij;
            k = k + 1;
        end
    end
    
    
%% Results
    imshow(Gray_Imgaes)

    
    
    
    
    
    
    
    