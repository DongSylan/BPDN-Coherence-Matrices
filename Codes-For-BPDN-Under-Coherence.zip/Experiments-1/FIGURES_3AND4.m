%% Initializing the enviroment
    close all
    clear 
    clc
    rng('default')
    
    
%% Load the functions 
    PATH_Current = cd;
    PATH_Functions = genpath(strrep(PATH_Current, 'Experiments-1', 'MyFunctions'));
    addpath(PATH_Functions);

   
%% Load the image data and coherence matrix
  % Load the image
    Image_Original = double(imread('Lenna.jpg'));
    Size_Image = size(Image_Original, 1);
  % Load the coherence matrix
    load Coherence_Matrix_04Rate.mat
    
    
%% Public settings
    Size_Window = 16;
    NUM_Row_OR_Column = Size_Image/Size_Window;
    Row_IndexGuider = kron(ones(1, NUM_Row_OR_Column), (1:NUM_Row_OR_Column)');
    Column_IndexGuider = Row_IndexGuider';


%% Lambda and mu 
    log10gamma_Set = -4:6;
    log10lambda_Set = -8:2;
    NUM_log10gamma = length(log10gamma_Set);
    NUM_log10lambda = length(log10lambda_Set);
    PSNR_Results = zeros(NUM_log10gamma, NUM_log10lambda);
    SSIM_Results = zeros(NUM_log10gamma, NUM_log10lambda);

   
%% Main
    for i = 1:NUM_log10gamma
        i
        Options.gamma = 10^log10gamma_Set(i);
        
        for j = 1:NUM_log10lambda
            
            lambda = 10^log10lambda_Set(j);
            
            Image_Recovered = zeros(Size_Image, Size_Image);
            for k = 1:(NUM_Row_OR_Column^2)
              % The index of the i-th segment
                Row_Index = (16*(Row_IndexGuider(k)-1) + 1):(16*Row_IndexGuider(k));
                Column_Index = (16*(Column_IndexGuider(k)-1) + 1):(16*Column_IndexGuider(k));
                
              % Obtain the i-th segment
                Image_Data = double(Image_Original(Row_Index, Column_Index));
                
              % Prepare for the input data
                FRONorm_Image = norm(Image_Data,  'fro');
                Image_Normalization = Image_Data/FRONorm_Image;
                C = dct2(Image_Normalization);
                x_Original = C(:);
                
              % Sampling
                b = A*x_Original;
                
              % Solve by BPDN
                Options.MAX_ITER = 1000;
                Options.x_Original = x_Original;
                x_sharp = BPDN(A, b, lambda, Options);
                
              % Output the imgae
                C_Recovered = reshape(x_sharp, Size_Window, Size_Window);
                Image_Data_Recovered = idct2(C_Recovered);
                Image_Recovered(Row_Index, Column_Index) = FRONorm_Image*Image_Data_Recovered;

            end
            
            Image_Recovered = max(Image_Recovered, 0);
            Image_Recovered = min(Image_Recovered, 255);
            PSNR_Results(i, j) = PSNR(Image_Original, Image_Recovered, ones(Size_Image, Size_Image));
            SSIM_Results(i, j) = ssim_index(Image_Original, Image_Recovered);
            
        end
        
    end
   
   
%% Figure
  % Show
    figure
    bar3(PSNR_Results)
    colormap('summer')
    xlabel('log_1_0\lambda', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('log_1_0\gamma', 'FontWeight', 'bold', 'FontSize', 20);
    zlabel('PSNR(dB)', 'FontWeight', 'bold', 'FontSize', 20)
    set(gca, 'FontSize', 20, 'FontWeight','bold', 'XTick', 1:2:NUM_log10lambda, 'XTickLabel', log10lambda_Set(1:2:NUM_log10lambda),...
        'YTick', 1:2:NUM_log10gamma, 'YTickLabel', log10gamma_Set(1:2:NUM_log10gamma));
    
    figure
    PSNR_Results_rot90 = rot90(PSNR_Results, 2);
    bar3(PSNR_Results_rot90)
    colormap('summer')
    xlabel('log_1_0\lambda', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('log_1_0\gamma', 'FontWeight', 'bold', 'FontSize', 20);
    set(gca, 'FontSize', 20, 'FontWeight','bold', 'XTick', 1:2:NUM_log10lambda, 'XTickLabel', fliplr(log10lambda_Set(1:2:NUM_log10lambda)),...
        'YTick', 1:2:NUM_log10gamma, 'YTickLabel', fliplr(log10gamma_Set(1:2:NUM_log10gamma)));  % fliplr---Exange the Left and Right. However, flipud---Exange the Up and Down
    zlabel('PSNR(dB)', 'FontWeight', 'bold', 'FontSize', 20)
    
    figure
    bar3(SSIM_Results)
    colormap('summer')
    xlabel('log_1_0\lambda', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('log_1_0\gamma', 'FontWeight', 'bold', 'FontSize', 20);
    zlabel('SSIM', 'FontWeight', 'bold', 'FontSize', 20)
    set(gca, 'FontSize', 20, 'FontWeight','bold', 'XTick', 1:2:NUM_log10lambda, 'XTickLabel', log10lambda_Set(1:2:NUM_log10lambda),...
        'YTick', 1:2:NUM_log10gamma, 'YTickLabel', log10gamma_Set(1:2:NUM_log10gamma));
    
    figure
    SSIM_Results_rot90 = rot90(SSIM_Results, 2);
    bar3(SSIM_Results_rot90)
    colormap('summer')
    xlabel('log_1_0\lambda', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('log_1_0\gamma', 'FontWeight', 'bold', 'FontSize', 20);
    set(gca, 'FontSize', 20, 'FontWeight','bold', 'XTick', 1:2:NUM_log10lambda, 'XTickLabel', fliplr(log10lambda_Set(1:2:NUM_log10lambda)),...
        'YTick', 1:2:NUM_log10gamma, 'YTickLabel', fliplr(log10gamma_Set(1:2:NUM_log10gamma)));  % fliplr---Exange the Left and Right. However, flipud---Exange the Up and Down
    zlabel('SSIM', 'FontWeight', 'bold', 'FontSize', 20)
    
    
    
%% Save data
    save FIGURES_3AND4
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions);
   