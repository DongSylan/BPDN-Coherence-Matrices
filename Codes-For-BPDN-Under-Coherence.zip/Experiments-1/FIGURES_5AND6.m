%% Initializing the enviroment
    close all
    clear
    clc
    rng('default')
    
    
%% Load the functions 
    PATH_Current = cd;
    PATH_Functions = genpath(strrep(PATH_Current, 'Experiments-1', 'MyFunctions'));
    addpath(PATH_Functions);

   
%% Load the image data and coherence matrix
  % Load the image
    Image_Original = double(imread('Lena.jpg'));
    Size_Image = size(Image_Original, 1);
  % Load the coherence matrix
    load Coherence_Matrix_04Rate.mat
    
    
%% Public settings
    Size_Window = 16;
    Length_Segment = Size_Window^2;
    NUM_Row_OR_Column = Size_Image/Size_Window;
    Row_IndexGuider = kron(ones(1, NUM_Row_OR_Column), (1:NUM_Row_OR_Column)');
    Column_IndexGuider = Row_IndexGuider';
    
    
%% Parameters for window
    iTH_SegmentShow = 201;
    Imresize_Ratio = 4;
    Location_Image_Resized = 'LeftTop'; % 'LeftTop', 'RightTop', 'LeftBottom', 'RightBottom'.
    Color_Window = 'g';
    LineStyle_Window = '-';
    
%% Settings for BPDN
    lambda = 1e-8;
    Options.gamma = 1e3;
    Options.MAX_ITER = 500;
    
   
%% Main
    Image_Recovered = zeros(Size_Image, Size_Image);
    for k = 1:(NUM_Row_OR_Column^2)
        
      % The index of the i-th segment
        Row_Index = (Size_Window*(Row_IndexGuider(k)-1) + 1):(Size_Window*Row_IndexGuider(k));
        Column_Index = (Size_Window*(Column_IndexGuider(k)-1) + 1):(Size_Window*Column_IndexGuider(k));
      % Obtain the i-th segment
        Segment_Original = double(Image_Original(Row_Index, Column_Index));

      % Prepare for the input data
        FRONorm_Segment = norm(Segment_Original,  'fro');
        Segment_Normalization = Segment_Original/FRONorm_Segment;
        C = dct2(Segment_Normalization);
        x_Original = C(:);

      % Sampling
        b = A*x_Original;

      % Solve by BPDN
        Options.x_Original = x_Original;
        [x_sharp, Error_RNIE, Error_RTIE] = BPDN(A, b, lambda, Options);

      % Output the imgae
        C_Recovered = reshape(x_sharp, Size_Window, Size_Window);
        Segment_Recovered = idct2(C_Recovered);
        Image_Recovered(Row_Index, Column_Index) = FRONorm_Segment*Segment_Recovered;
        
        if k == iTH_SegmentShow
            
          % Window for segment
            Position_Window = [Column_Index(1) Row_Index(1) 16 16];  % [XMIN YMIN WIDTH HEIGHT]
          % Convergence
            SegmentShow_Error_RTIE = Error_RTIE;
          % Output the imgae
            C_Recovered = reshape(x_sharp, Size_Window, Size_Window);
            SegmentShow_Recovered = idct2(C_Recovered);
            SegmentShow_Recovered = FRONorm_Segment*SegmentShow_Recovered;
            SegmentShow_Recovered = max(SegmentShow_Recovered, 0);
            SegmentShow_Recovered = min(SegmentShow_Recovered, 255);
          % PSNR and SSIM
            PSNR_SegmentShow = PSNR(Segment_Original, SegmentShow_Recovered, ones(Size_Window, Size_Window));
            SSIM_SegmentShow = ssim_index(Segment_Original, SegmentShow_Recovered);
            
        end

    end

    Image_Recovered = max(Image_Recovered, 0);
    Image_Recovered = min(Image_Recovered, 255);
    PSNR_Image = PSNR(Image_Original, Image_Recovered, ones(Size_Image, Size_Image));
    SSIM_Image = ssim_index(Image_Original, Image_Recovered);
   
   
%% Show
    figure
    imshow(uint8(Image_Original))
    
    figure
    imshow(uint8(Image_Recovered))
    
    disp(['PSNR of BPDN for Lena is ' num2str(PSNR_Image) 'dB.'])
    disp(['SSIM of BPDN for Lena is ' num2str(SSIM_Image)])
    
    figure
    Image_Synthesizer(uint8(Image_Original), Position_Window, Imresize_Ratio, Location_Image_Resized, Color_Window, LineStyle_Window);
    
    figure
%     imwrite(Segment_Recovered, 'Segment_Recovered_BPDN.jpg') 
    imshow(uint8(SegmentShow_Recovered), 'InitialMagnification', 'fit')
    
    disp(['PSNR of BPDN for the given segment is ' num2str(PSNR_SegmentShow) 'dB.'])
    disp(['SSIM of BPDN for the given segment is ' num2str(SSIM_SegmentShow)])
    
    figure
    h2 = plot(log10(SegmentShow_Error_RTIE));
    set(h2, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 2)
    xlabel('i-th iteration', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('log_1_0RTIE(i)', 'FontWeight', 'bold', 'FontSize', 20);
    set(gca,'FontSize', 20, 'FontWeight','bold')
    grid on  
    
    
%% Save data
    save FIGURES_5AND6
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions);
   