%% Initialize the enviroment
    close all
    clear
    clc
    rng('default')
    
    
%% Load data
    load FECG_Data\FOETAL_ECG.mat
    
    
%% Data show
    N = size(FOETAL_ECG, 2) - 1;
    figure
    for i = 1:N
        subplot(N, 1, i)
        h = plot(FOETAL_ECG(:, i+1));
        set(h, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 2)
%         set(gca,'FontSize', 20, 'FontWeight','bold', 'XTick', [0, 500, 1000, 1500, 2000, 2500], 'position', [0.1, 0.5, 0.8, 0.1])  % 'position', [left, bottom, width, heigh]
        grid on
    end
    