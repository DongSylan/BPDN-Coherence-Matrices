%% Initializing the enviroment
    close all
    clear
    clc
    rng('default')
    
    
%% Load the functions 
    PATH_Current = cd;
    PATH_Functions = genpath(strrep(PATH_Current, 'Experiments-2', 'MyFunctions'));
    addpath(PATH_Functions);
    
   
%% Load the FECG data
  % Load the FECG data
    load FECG_Data\FOETAL_ECG.mat
    Length_Segment = 250;
    x_Original = FOETAL_ECG(1:Length_Segment, 3);
    
    
%% Generate the desired coherence matrix
    Sampling_rate = 0.5;
    m = round(Sampling_rate*Length_Segment);
    A_randn = randn(m, Length_Segment);
    A = DesignGrass(m, Length_Segment, 2e3, 0.90, 0.90, A_randn);
    save('Coherence_Matrix_m125.mat', 'A')
   
    
%% Sampling
    b = A*x_Original;
    
    
%% Public settings
    sRate_Set = 0.01:0.01:0.1;
    NUM_sRate_Set = length(sRate_Set);

    
%% Main
    SNR_IHT_sRate = zeros(NUM_sRate_Set, 1);
    SNR_ROMP_sRate = zeros(NUM_sRate_Set, 1);
    SNR_SP_sRate = zeros(NUM_sRate_Set, 1);
    SNR_IHT_BEST = -inf;
    SNR_ROMP_BEST = -inf;
    SNR_SP_BEST = -inf;
    s_IHT_Best = round(0.06*Length_Segment);
    s_ROMP_Best = round(0.03*Length_Segment);
    s_SP_Best = round(0.07*Length_Segment);
    for i = 1:NUM_sRate_Set
        i
        s = round(sRate_Set(i)*Length_Segment);
        
      % ------ Solve by IHT
        x_sharp_IHT = hard_l0_Mterm(b, A, Length_Segment, s);
        SNR_IHT = 20*log10(norm(x_Original)/norm(x_sharp_IHT-x_Original));
        SNR_IHT_sRate(i) = SNR_IHT;
        
        if SNR_IHT_BEST <= SNR_IHT;
            SNR_IHT_BEST = SNR_IHT;
            s_IHT_Best = s;
            x_sharp_IHT_Best = x_sharp_IHT;
        end
        
      % ------ Solve by ROMP
        x_sharp_ROMP = romp(A, b, s);
        SNR_ROMP = 20*log10(norm(x_Original)/norm(x_sharp_ROMP-x_Original));
        SNR_ROMP_sRate(i) = SNR_ROMP;
        
        if SNR_ROMP_BEST <= SNR_ROMP;
            SNR_ROMP_BEST = SNR_ROMP;
            s_ROMP_Best = s;
            x_sharp_ROMP_Best = x_sharp_ROMP;
        end
        
      % ------ Solve by SP
        x_sharp_SP = CSRec_SP(s, A, b); 
        SNR_SP = 20*log10(norm(x_Original)/norm(x_sharp_SP-x_Original));
        SNR_SP_sRate(i) = SNR_SP;
        
        if SNR_SP_BEST <= SNR_SP;
            SNR_SP_BEST = SNR_SP;
            s_SP_Best = s;
            x_sharp_SP_Best = x_sharp_SP;
        end
        
    end
        
    
%% Result show
    disp(['The best sparsity and SNR for IHT are ' num2str(s_IHT_Best) ' and ' num2str(SNR_IHT_BEST) 'dB, respectively.'])
    disp(['The best sparsity and SNR for ROMP are ' num2str(s_ROMP_Best) ' and ' num2str(SNR_ROMP_BEST) 'dB, respectively.'])
    disp(['The best sparsity and SNR for SP are ' num2str(s_SP_Best) ' and ' num2str(SNR_SP_BEST) 'dB, respectively.'])
    

%% Figure 
    figure
    plot(x_Original)
    grid on
    
    figure
    plot(x_sharp_IHT_Best)
    grid on
    
    figure
    plot(x_sharp_ROMP_Best)
    grid on
    
    figure
    plot(x_sharp_SP_Best)
    grid on
    
    
%% Save data
    save FIGURES_10AND11abc
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions);
   