%% Initializing the enviroment
    close all
    clear
    clc
    rng('default')
    
    
%% Load the functions 
    PATH_Current = cd;
    PATH_Functions = genpath(strrep(PATH_Current, 'Experiments-2', 'MyFunctions'));
    addpath(PATH_Functions);
    
   
%% Load the FECG data and the desired coherence matrix
  % Load the FECG data
    load FECG_Data\FOETAL_ECG.mat
    Length_Segment = 250;
    x_Original = FOETAL_ECG(1:Length_Segment, 3);
  % Load the desired coherence matrix
    load Coherence_Matrix_m125.mat
   
    
%% Sampling
    b = A*x_Original;
    
    
%% Settings for BPDN
    lambda_BPDN = 1e0;
    opts_BPDN.gamma = 1e0;
    opts_BPDN.MAX_ITER = 500;
    opts_BPDN.x_Original = x_Original;
    
   
%% Main
  % ------ Solve by Block-BPDN
    [x_sharp_BPDN, Error_RNIE, Error_RTIE] = BPDN(A, b, lambda_BPDN, opts_BPDN);
    SNR_BPDN = 20*log10(norm(x_Original)/norm(x_sharp_BPDN-x_Original))
    
   
%% Figure
    figure
    plot(x_sharp_BPDN)
    grid on
    
    
    %% Save data
    save FIGURE11d
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions);
   