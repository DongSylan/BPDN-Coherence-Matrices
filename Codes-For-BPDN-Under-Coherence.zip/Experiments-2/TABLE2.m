%% Initializing the enviroment
    close all
    clear 
    clc
    rng('default')
    
    
%% Load the functions 
    PATH_Current = cd;
    PATH_Functions = genpath(strrep(PATH_Current, 'Experiments-2', 'MyFunctions'));
    addpath(PATH_Functions);

   
%% Load the FECG data and the desired coherence matrix
    load FECG_Data\FOETAL_ECG.mat
    Data_Original = FOETAL_ECG(:, 2:end);
    [M_FECG, N_FECG] = size(Data_Original);
  % Load the desired coherence matrix
    load Coherence_Matrix_m125.mat 
    load Coherence_Matrix_m125_Block.mat
    
    
%% Public settings
    Length_Segment = 250;
    
    
%% Parameter setings for algorithms
  % IHT
    s_IHT = 18;
  % ROMP
    s_ROMP = 10;
  % SP
    s_SP = 18;
  % BPDN
    lambda_BPDN = 1e0;
    opts_BPDN.gamma = 1e0;
    opts_BPDN.MAX_ITER = 500;
  % Block-BPDN
    d = 25;   % block scale
    Matrix_Block_Label = repmat(1:(Length_Segment/d), d, 1);
    Block_Label = Matrix_Block_Label(:); % Block-Label
    lambda_Block_BPDN = 1e-2;
    opts_Block_BPDN.gamma = 1e-1;
    opts_Block_BPDN.MAX_ITER = 500;
    
   
%% Main
    SNR_IHT = zeros(1, N_FECG);
    SNR_ROMP = zeros(1, N_FECG);
    SNR_SP = zeros(1, N_FECG);
    SNR_BPDN = zeros(1, N_FECG);
    SNR_Block_BPDN = zeros(1, N_FECG);
    for i = 1:N_FECG
        i
        iSegment_Original = Data_Original(:, i);
        
        iSegment_Recovery_IHT = zeros(M_FECG, 1);
        iSegment_Recovery_ROMP = zeros(M_FECG, 1);
        iSegment_Recovery_SP = zeros(M_FECG, 1);
        iSegment_Recovery_BPDN = zeros(M_FECG, 1);
        iSegment_Recovery_Block_BPDN = zeros(M_FECG, 1);
        for j = 1:10
            J = (1+250*(j-1)):(250*j);
            
          % Sampling
            x_Original = Data_Original(J, i);
            b = A*x_Original;
            b_Block = A_Block*x_Original;
            
          % ------ Solve by IHT
            iSegment_Recovery_IHT(J) = hard_l0_Mterm(b, A, Length_Segment, s_IHT);
            
          % ------ Solve by ROMP
            iSegment_Recovery_ROMP(J) = romp(A, b, s_ROMP);
            
          % ------ Solve by SP
            iSegment_Recovery_SP(J) = CSRec_SP(s_SP, A, b); 
            
          % ------ Solve by BPDN
            opts_BPDN.x_Original = x_Original;
            iSegment_Recovery_BPDN(J) = BPDN(A, b, lambda_BPDN, opts_BPDN);
            
          % ------ Solve by Block-BPDN
            opts_Block_BPDN.x_Original = x_Original;
            iSegment_Recovery_Block_BPDN(J) = Block_BPDN(A_Block, b_Block, Block_Label, lambda_Block_BPDN, opts_Block_BPDN);
            
        end
        SNR_IHT(i) = 20*log10(norm(iSegment_Original)/norm(iSegment_Recovery_IHT-iSegment_Original));
        SNR_ROMP(i) = 20*log10(norm(iSegment_Original)/norm(iSegment_Recovery_ROMP-iSegment_Original));
        SNR_SP(i) = 20*log10(norm(iSegment_Original)/norm(iSegment_Recovery_SP-iSegment_Original));
        SNR_BPDN(i) = 20*log10(norm(iSegment_Original)/norm(iSegment_Recovery_BPDN-iSegment_Original));
        SNR_Block_BPDN(i) = 20*log10(norm(iSegment_Original)/norm(iSegment_Recovery_Block_BPDN-iSegment_Original));

    end
    
    
%% Save data
    save TABLE2
    
    
%% Show
    disp(vpa(SNR_IHT, 4))
    disp(vpa(SNR_ROMP, 4))
    disp(vpa(SNR_SP, 4))
    disp(vpa(SNR_BPDN, 4))
    disp(vpa(SNR_Block_BPDN, 4))
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions);
   