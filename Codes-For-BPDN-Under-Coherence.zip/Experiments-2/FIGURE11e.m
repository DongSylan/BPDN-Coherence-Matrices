%% Initializing the enviroment
    close all
    clear
    clc
    rng('default')
    
    
%% Load the functions 
    PATH_Current = cd;
    PATH_Functions = genpath(strrep(PATH_Current, 'Experiments-2', 'MyFunctions'));
    addpath(PATH_Functions);
    
   
%% Load the FECG data and the desired coherence matrix
  % Load the FECG data
    load FECG_Data\FOETAL_ECG.mat
    Length_Segment = 250;
    x_Original = FOETAL_ECG(1:Length_Segment, 3);
    
    
%% Generate the desired block coherence matrix
    d = 25;
    m_d = 5;
    n_d = 10;
    P_randn = randn(m_d, n_d);
    P = DesignGrass(m_d, n_d, 2e3, 0.90, 0.90, P_randn);
    D = dctmtx(d);
    A_Block = kron(P, D); % m = m_d*d = 125; % n = n_d*d = 250;  A is an m*n matrix
    save('Coherence_Matrix_m125_Block.mat', 'A_Block')
    
    
%% Sampling
    b = A_Block*x_Original;
    
    
%% Settings for Block-BPDN
    Matrix_Block_Label = repmat(1:(Length_Segment/d), d, 1);
    Block_Label = Matrix_Block_Label(:); % Block-Label
    lambda_Block_BPDN = 1e-2;
    opts_Block_BPDN.gamma = 1e-1;
    opts_Block_BPDN.MAX_ITER = 500;
    opts_Block_BPDN.x_Original = x_Original;
    
   
%% Main
  % ------ Solve by Block-BPDN
    [x_sharp_Block_BPDN, Error_RNIE, Error_RTIE] = Block_BPDN(A_Block, b, Block_Label, lambda_Block_BPDN, opts_Block_BPDN);
    SNR_Block_BPDN = 20*log10(norm(x_Original)/norm(x_sharp_Block_BPDN-x_Original))
    
   
%% Figure
    figure
    plot(x_sharp_Block_BPDN)
    grid on
    
    
    %% Save data
    save FIGURE11e
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions);
   