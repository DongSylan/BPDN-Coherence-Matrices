%% Initializing the enviroment
   close all
   clear
   clc
   rng('default')
   
   
%% Load the functions 
    PATH_Current = cd;
    PATH_Functions = genpath(strrep(PATH_Current, 'Experiments-0', 'MyFunctions'));
    addpath(PATH_Functions);
   
    
%% Public parameters
    Num_Inds = 20;
    n = 256;                 % The length of signal
    mRate_Set = 0.1:0.05:0.7;
    NUM_mRate_Set = length(mRate_Set);
    
%% Main
    M_Coherence_A_randn_Set = zeros(NUM_mRate_Set, 1);
    M_Coherence_A_Set = zeros(NUM_mRate_Set, 1);
    M_DesiredCoherence_Set = zeros(NUM_mRate_Set, 1);
    for i = 1:NUM_mRate_Set
        i
        m = round(mRate_Set(i)*n);
      % desired coherence
        M_DesiredCoherence_Set(i) = sqrt((n-m)/(m*(n-1)));
        
        for j = 1:Num_Inds
          % coherence for A_randn
            A_randn = randn(m, n);
            M_Coherence_A_randn_Set(i) = M_Coherence_A_randn_Set(i) + coherence(A_randn)/Num_Inds;
            
          % coherence for A
            A = DesignGrass(m, n, 2e3, 0.90, 0.90, A_randn);
            M_Coherence_A_Set(i) = M_Coherence_A_Set(i) + coherence(A)/Num_Inds;
        end
        
    end
    
    
%% Figure
    figure
    h1 = plot(mRate_Set, M_Coherence_A_randn_Set);
    set(h1, 'Color', 'b', 'LineStyle', '-', 'LineWidth', 2, 'MarkerSize', 10)
    hold on
    h2 = plot(mRate_Set, M_Coherence_A_Set);
    set(h2, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 2, 'MarkerSize', 10)
    h3 = plot(mRate_Set, M_DesiredCoherence_Set);
    set(h3, 'Color', 'k', 'LineStyle', '--', 'LineWidth', 2, 'MarkerSize', 10)
    Coherence_legend = legend([h1, h2], 'Input random matrix', 'Output matrix', 'Location', [0.5, 0.37, 0.15, 0.15]);
    set(Coherence_legend,  'FontWeight', 'bold', 'FontSize', 20); % [left, bottom, width, heigh]=[0.2, 0.2, 0.15, 0.15] 
    xlabel('Sampling rate (m/n)', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('\mu(\cdot)', 'FontWeight', 'bold', 'FontSize', 20);
    set(gca,'FontSize', 20, 'FontWeight','bold')
    grid on
    
    
%% Save
    save FIGURE2
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions);
   
   