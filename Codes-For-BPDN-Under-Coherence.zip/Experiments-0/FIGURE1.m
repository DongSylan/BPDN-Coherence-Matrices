%% Initializing the enviroment
   close all
   clear
   clc
   rng('default')
   
   
%% Load the functions 
    PATH_Current = cd;
    PATH_Functions = genpath(strrep(PATH_Current, 'Experiments-0', 'MyFunctions'));
    addpath(PATH_Functions);
   
   
%% Public parameters
    n = 256;                 % The length of signal
    mRate = 0.4;
  % Generate the desired matrix with small coherence
    m = round(mRate*n); 
    A_randn = randn(m, n);
    
    
%% Generate the desired matrix
    A = DesignGrass(m, n, 2e3, 0.90, 0.90, A_randn);
  % Save the obtained coherence matrix A
    save('Coherence_Matrix_04Rate.mat', 'A')
    
    
%% Performance of A
    Indices_Set = nchoosek(1:n, 2);
    Length_Indices = length(Indices_Set);
    Coherence_Set_randn = zeros(Length_Indices, 1);
    Coherence_Set = zeros(Length_Indices, 1);
    for i = 1:Length_Indices
        
    %%---Coherence of A_randn
      % Indices_Set(i, 1)-th and Indices_Set(i, 2)-th columns of A_randn
        A_randni1 = A_randn(:, Indices_Set(i, 1));
        A_randni2 = A_randn(:, Indices_Set(i, 2));
      % Compute the coherence for two different columns of A_randn
        Coherence_Set_randn(i) = abs(dot(A_randni1, A_randni2))/(norm(A_randni1)*norm(A_randni2));
        
    %%---Coherence of A
      % Indices_Set(i, 1)-th and Indices_Set(i, 2)-th columns of A
        Ai1 = A(:, Indices_Set(i, 1));
        Ai2 = A(:, Indices_Set(i, 2));
      % Compute the coherence for two different columns of A
        Coherence_Set(i) = abs(dot(Ai1, Ai2))/(norm(Ai1)*norm(Ai2));
        
    end
  % Sort in ascend order
    Coherence_Set_randn = sort(Coherence_Set_randn, 'ascend');
    Coherence_Set = sort(Coherence_Set, 'ascend');
    
    
%% Welch bound
    Welch_Bound = sqrt((n-m)/(m*(n-1)));
    
    
%% Figure
    figure
    h1 = plot(1:Length_Indices, Coherence_Set_randn);
    set(h1, 'Color', 'b', 'LineStyle', '-', 'LineWidth', 2, 'MarkerSize', 10)
    hold on
    h2 = plot(1:Length_Indices, Coherence_Set);
    set(h2, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 2, 'MarkerSize', 10)
    h3 = plot(1:Length_Indices, Welch_Bound*ones(Length_Indices, 1));
    set(h3, 'Color', 'k', 'LineStyle', '--', 'LineWidth', 2, 'MarkerSize', 10)
    Coherence_legend = legend([h1, h2], 'Input random matrix', 'Output matrix', 'Location', [0.4, 0.6, 0.15, 0.15]);
    set(Coherence_legend,  'FontWeight', 'bold', 'FontSize', 20); % [left, bottom, width, heigh]=[0.2, 0.2, 0.15, 0.15] 
    xlabel('Column index pair (i, j) of matrix', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('F_i_\neq_j(\cdot)(sorted in ascending order)', 'FontWeight', 'bold', 'FontSize', 20);
    xlim([1, 33000])
    set(gca,'FontSize', 20, 'FontWeight','bold')
    grid on
 
    
%% Save
    save FIGURE1
   
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions); 
    