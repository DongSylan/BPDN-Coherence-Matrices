function [H_All, W1_True, W2_True] = Size_TwoImage(W1, H1, W2, H2, W_Used)

   H_All = W_Used/(W1/H1 + W2/H2);
   H_All = vpa(H_All, 3);
   W1_True = vpa(W1*H_All/H1, 3);
   W2_True = vpa(W2*H_All/H2, 3);
end

