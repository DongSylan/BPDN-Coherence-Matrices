function [J1,best,w,i] = Reg_Vector(u,s)
% realise the regulation of vectors(supp).
%   u��vectors(supp)
%   s: sparsity 
%  J1: result 

absu = abs(u);
[Jval, ix] = sort(absu, 'descend');
J = ix(1:s);
Jvals = Jval(1:s);
%Find J1, the set of comparable coordinates with maximal energy 
best = -1;
   
for i = 1:s
   w = sum(Jvals(i) <= 2*Jvals(i:s));    
   if w == s-i+1
       best_1 = sum(Jvals(i:s).^2);
       if best_1 > best
           best = best_1;
           J1 = sort(J(i:s));
       end
       break      
   else
       best_1 = sum(Jvals(i:i+w-1).^2);
       if best_1 > best
          best = best_1;
          J1 = sort(J(i:i+w-1)); 
       end          
   end 
end
end
   
   
   

