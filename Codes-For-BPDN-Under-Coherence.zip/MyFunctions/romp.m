function [xOut, numIts] = romp(Phi, b, s)

%%% PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%
% d = ambient dimension of the signal v
% N = number of measurements
% n = sparsity level of n
% Phi = N by d measurement matrix
% x = measurement vector (Phi * v)
% vOut = reconstructed signal 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% FUNCTION DESCRIPTION %%%%%%%%%%%%%%%%%
% romp takes parameters as described
% above. Given the sparsity level n and
% the N by d measurement matrix Phi, and
% the measurement vector x = Phi * v, romp
% reconstructs the original signal v.
% This reconstruction is the output.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


n = size(Phi, 2);
x_e = zeros(n,1);

% Set residual
r = b;

%Set index set to "empty"
I = [];

%Counter (to be used optionally)
numIts = 0;

%Run ROMP
while length(I) < 2*s && norm(r) > 1e-6

   numIts = numIts + 1;

   %Find J, the biggest n coordinates of u
   
   u = Phi' * r;
[J0,~,~] = Reg_Vector(u,s);

   %Add J0 to the index set I
   I = union(I,J0);
   
    %Update the residual
   PhiSubI = Phi(:,I);
%    xSubI = lscov(PhiSubI, b);
   xSubI = PhiSubI\b;
   x_e(I) = xSubI;
   r = b - PhiSubI * xSubI;

end %  
xOut = x_e;

end
               

