function [x_sharp, Error_RNIE, Error_RTIE] = BPDN(A, b, lambda, Options)

% Basis Pursuit DeNoise (BPDN)  Solve BPDN via ADMM

% x_sharp = BPDN(A, b, lambda, Options)
%
% Solves the following problem via ADMM:
%
%   minimize     ||x||_{1}+(1/(2*lambda))\|b-Ax\|_{2}^2 
%
% The solution is returned in the vector optimal_solution.

% When use this code remember that we have used the following skill
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  (A'A+c*I)^{-1}=I/c - A'(I + A*A'/c)^{-1}A/(c^{2})
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[m, n] = size(A);

gamma = Options.gamma;
MAX_ITER = Options.MAX_ITER;
x_Original = Options.x_Original;
ABSTOL = 1e-7;
RELTOL = 1e-4;

x_Old = zeros(n,1);
y_Old = zeros(n,1);
z_Old = zeros(n,1);

 Error_RNIE = zeros(MAX_ITER, 1);    % Relative Neighboring Iteration Error (RNIE)
 Error_RTIE = zeros(MAX_ITER, 1);    % Relative True Iteration Error (RTIE)
 
for k = 1:MAX_ITER
    
  % x-Update
    lambda_gamma = lambda*gamma;
    g = y_Old - z_Old/gamma;
    p0 = A'*b + lambda_gamma*g;
    p1 = A*p0;
    A0 = eye(m) + A*A'/lambda_gamma;
    x_New = p0 - A'*(A0\p1)/lambda_gamma;
    x_New = x_New/lambda_gamma;
    
  % y-Update
    p = x_New + z_Old/gamma;
    y_New = shrinkage_L1(p, 1/gamma);
    
  % z-Update
    z_New = z_Old + gamma*(x_New - y_New);
  
  % termination checks
    Relative_Error = norm(x_New - x_Old, 2)/max(norm(x_New, 2), 1);
    Error_RNIE(k) = Relative_Error;
    Error_RTIE(k) = norm(x_New - x_Original, 2)/norm(x_Original, 2);
    
    
  % stopping condition for ADMM
    r = norm(x_New-y_New);
    s = norm(-gamma*(y_New-y_Old));
    
    eps_pri = sqrt(n)*ABSTOL + RELTOL*max(norm(x_New), norm(-y_New));
    eps_dual = sqrt(n)*ABSTOL + RELTOL*norm(z_New);
    
    if (r < eps_pri && s < eps_dual)
        Error_RNIE = Error_RNIE(1:k);
        Error_RTIE = Error_RTIE(1:k);
        break
    else
        x_Old = x_New;
        y_Old = y_New;
        z_Old = z_New;
    end

end
x_sharp = x_New;

end

function y = shrinkage_L1(a, kappa)
    y = max(0, a-kappa) - max(0, -a-kappa);
end

